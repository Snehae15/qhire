<?php
include 'connection.php';
// $std_id= $_POST['id'];
$name = $_POST['name'];
$dob = $_POST['dob'];
$phone_no = $_POST['phone_no'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$qualification = $_POST['qualification'];
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
<<<<<<< HEAD
=======
$upload_resume = $_POST['resume'];
$sql = mysqli_query($con, "INSERT INTO reg_student(name,dob,phone_no,gender,address,qualification,username,password,email,resume,status)VALUES('$name','$dob','$phone_no',''$gender,'$address','$qualifiaction','$username','$password','$email','$resume','pending')");
>>>>>>> 78dd23ee1228c14f9e52f69489d763b4b158cc1a

$resume = $_POST['resume'];
$type = $_POST['type'];

$sql1 = mysqli_query($con, "INSERT INTO login(email,password,type)VALUES('$email','$password','$type')");
$log_id = mysqli_insert_id($con);

$sql2 = mysqli_query($con, "INSERT INTO reg_student(log_id,name,dob,phone_no,gender,address,qualification,username,password,email,resume,status,type)VALUES('$log_id','$name','$dob','$phone_no','$gender','$address','$qualification','$username','$password','$email','$resume','Pending','$type')");

if ($sql1 && $sql2 )
{
    $myarray['message'] = 'Added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>