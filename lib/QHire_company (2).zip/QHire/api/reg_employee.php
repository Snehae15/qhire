<?php
include 'connection.php';
$name = $_POST['name'];
$dob = $_POST['dob'];
$phone_no = $_POST['phone_no'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$qualification = $_POST['qualification'];
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$ep_status = $_POST['ep_status'];
$upload_resume = $_POST['upload_resume'];
<<<<<<< HEAD
$type = $_POST['type'];
$sql1 = mysqli_query($con, "INSERT INTO login(email,password,type)VALUES('$email','$password','$type')");
$login_id = mysqli_insert_id($con);
=======
$status ='Pending';
$sql = mysqli_query($con, "INSERT INTO reg_emp(name,dob,phone_no,gender,address,qualification,username,password,email,ep_status,upload_resume,status)VALUES('$name','$dob','$phone_no','$gender','$address','$qualification','$username','$password','$email','$ep_status','$upload_resume','$status')");
>>>>>>> 78dd23ee1228c14f9e52f69489d763b4b158cc1a

$sql2 = mysqli_query($con, "INSERT INTO reg_emp(login_id,name,dob,phone_no,gender,address,qualification,username,password,email,ep_status,upload_resume,type)VALUES('$login_id','$name','$dob','$phone_no','$gender','$address','$qualification','$username','$password','$email','$ep_status','$upload_resume','$type')");

if ($sql1 && $sql2 )
{
    $myarray['message'] = 'Added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>