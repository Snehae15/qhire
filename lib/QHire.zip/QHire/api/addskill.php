<?php
include 'connection.php';

$skill=$_POST['skill'];

$sql=mysqli_query($con,"INSERT INTO skill(skill)VALUES('$skill')");

if($sql)
{
    $myaddress['message']='added';
}
else
{
    $myaddress['message']='failed';
}
echo json_encode($myaddress);
?>

