<?php
include 'connection.php';

// Check if id is sent via POST
if(isset($_POST['id'])){
  $id = $_POST['id'];

  // Query to select all posts information for the user with the given id
  $sql = mysqli_query($con, "SELECT * FROM login JOIN posts ON login.log_id = posts.log_id;");
  
  // Check if any rows were returned
  if($sql->num_rows > 0){
    $list = array();
    while($row = mysqli_fetch_assoc($sql)){
      // Create a new array to store the post information
      $myarray = array();

      // Add a message to indicate success
      $myarray['message'] = 'viewed';
       
      // Add the post information to the array
      $myarray['postname'] = $row['postname'];
      $myarray['description'] = $row['description'];
      $myarray['uploadfile'] = $row['uploadfile'];

      // Add the array to the list of posts
      array_push($list, $myarray);
    }

    // Output the list of posts as a JSON string
    echo json_encode($list);
  } else {
    // If no rows were returned, output a message indicating failure
    $myarray = array('message' => 'failed');
    echo json_encode($myarray);
  }
} else {
  // If id is not sent via POST, output a message indicating failure
  $myarray = array('message' => 'id not provided');
  echo json_encode($myarray);
}
?>
