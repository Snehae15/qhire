<!DOCTYPE html>
<html>
<head>
	<title>MOCK INTERVIEW</title>
</head>
<body>

	<p>INTERVIEW</p>
	<?php
		$interview_id = "VIDEO_ID_HERE";
		$video_name = "VIDEO_NAME_HERE";
		$link = "https://youtu.be/NqWP-pl1CfQ?list=PLu0W_9lII9aikXkRE0WxDt1vozo3hnmtR$video_id";
		echo "<a href='$link'>$video_name</a>";
	?>
</body>
</html>
