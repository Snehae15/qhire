<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand" href="index.php"><span class="fa fa-area-chart"></span>QHIRE<span class="dashboard_text">Design dashboard</span></a></h1>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header">MAIN NAVIGATION</li>
              <li class="treeview">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			  <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>ADD</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
<<<<<<< HEAD
                  <li><a href="addnews.php"><i class="fa fa-angle-right"></i> NEWS</a></li>
                  <li><a href="addskillassessment.php"><i class="fa fa-angle-right"></i> SKILL ASSESSMENT</a></li>
                  <li><a href="addcourse.php"><i class="fa fa-angle-right"></i> COURSES</a></li>
                  <li><a href="verifycompany.php"><i class="fa fa-angle-right"></i> ALUMINI TALK</a></li>
                  <li><a href="interviewpreparation.php"><i class="fa fa-angle-right"></i> INTERVIEW PREPARATION</a></li>
                  <li><a href="verifycompany.php"><i class="fa fa-angle-right"></i> Q & A</a></li>                </ul>
              </li>
             
              <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>CONDUCT</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
              <ul class="treeview-menu">
                  <li><a href="addmockinterview.php"><i class="fa fa-angle-right"></i> MOCK INTERVIEW</a></li>
                  <li><a href="addmocktest.php"><i class="fa fa-angle-right"></i> MOCK TEST</a></li>
                  
                </ul>
                <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>VIEW</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
              <ul class="treeview-menu">
                  <li><a href="viewallstudents.php"><i class="fa fa-angle-right"></i>VIEW ALL STUDENTS</a></li>
                  <li><a href="viewallemployee.php"><i class="fa fa-angle-right"></i> VIEW ALL EMPLOYEE</a></li>
                  <li><a href="viewallcompany.php"><i class="fa fa-angle-right"></i>VIEW ALL COMPANY</a></li>
                  <li><a href="viewnews.php"><i class="fa fa-angle-right"></i>VIEW ALL NEWS</a></li>
                  <li><a href="viewallskillassessment.php"><i class="fa fa-angle-right"></i> VIEW ALL SKILL ASSESSMENT</a></li>
                  <li><a href="viewcourse.php"><i class="fa fa-angle-right"></i>VIEW ALL COURSES</a></li>
                  <li><a href="interviewpreparation.php"><i class="fa fa-angle-right"></i>VIEW ALL INTERVIEW PREPARATION</a></li>
                  <li><a href="viewallqa.php"><i class="fa fa-angle-right"></i> VIEW ALL Q&A</a></li>
                  <li><a href="mockinterview.php"><i class="fa fa-angle-right"></i> VIEW MOCK INTERVIEW</a></li>
</ul>
              <!-- </li>
=======
                  <li><a href="verifystudent.php"><i class="fa fa-angle-right"></i> Verify Students</a></li>
                  <li><a href="verifyemployee.php"><i class="fa fa-angle-right"></i> Verify Employees</a></li>
                  <li><a href="verifycompany.php"><i class="fa fa-angle-right"></i> Verify Company</a></li>
                  
                </ul>
            
            
             </li>
>>>>>>> 78dd23ee1228c14f9e52f69489d763b4b158cc1a
              <li class="treeview">
                <a href="#">
                <i class="fa fa-edit"></i> <span>Forms</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a> 
                <ul class="treeview-menu">
<<<<<<< HEAD
                  <li><a href="form.php"><i class="fa fa-angle-right"></i> General Forms</a></li>
                  <li><a href="validation.html"><i class="fa fa-angle-right"></i> Form Validations</a></li>
                </ul>
              </li>
            
              
                <ul class="treeview-menu">
                  <li><a href="login.php"><i class="fa fa-angle-right"></i> Login</a></li>
                  <li><a href="signup.html"><i class="fa fa-angle-right"></i> Register</a></li>
                  <li><a href="404.html"><i class="fa fa-angle-right"></i> 404 Error</a></li>
                  <li><a href="500.html"><i class="fa fa-angle-right"></i> 500 Error</a></li>
                  <li><a href="blank-page.html"><i class="fa fa-angle-right"></i> Blank Page</a></li>
                </ul> -->
=======
                  <li><a href="login.php"><i class="fa fa-angle-right"></i> Login</a></li>
                  <!-- <li><a href="signup.html"><i class="fa fa-angle-right"></i> Register</a></li>
                  <li><a href="404.html"><i class="fa fa-angle-right"></i> 404 Error</a></li>
                  <li><a href="500.html"><i class="fa fa-angle-right"></i> 500 Error</a></li>
                  <li><a href="blank-page.html"><i class="fa fa-angle-right"></i> Blank Page</a></li> -->
                </ul>
>>>>>>> 78dd23ee1228c14f9e52f69489d763b4b158cc1a
              
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>