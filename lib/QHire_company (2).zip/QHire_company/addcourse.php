<?php
include 'connection.php';
if(isset($_POST['sub'])){
  $name = $_POST['name'];
  $link = $_POST['link'];
  $content = $_POST['content'];
  mysqli_query($con,"insert into course(name,link,content)values('$name','$link','$content')");

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Course</title>
	<style>
		form {
			display: fixed;
			flex-direction: column;
			align-items: center;
			margin-top: 50px;
			font-family: Arial, sans-serif;
			font-size: 16px;
		}
		
		label, input, textarea {
			margin-bottom: 10px;
			padding: 5px;
			border-radius: 5px;
			border: 2px;
			width: 300px;
			box-sizing: border-box;
		}
		
		input[type="submit"] {
			margin-top: 10px;
			background-color: black;
			color: white;
			cursor: pointer;
		}
		
		input[type="submit"]:hover {
			background-color: gray;
		}
	</style>
</head>
<body>
	<h1>Add a Course</h1>
	<form method="POST" action="submit.php">
		<label for="video-name"> Name:</label>
		<input type="text" name="video-name" id="video-name" required>
		
		<label for="youtube-link">Link:</label>
		<input type="url" name="youtube-link" id="youtube-link" required>
		
		<label for="content">Content:</label>
		<textarea name="content" id="content" required></textarea>
		
		<input type="submit" value="Submit">
	</form>

	<?php

if ($conn->query($sql) === TRUE) {
	echo "Video added successfully";
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

</body>
</html>