<!DOCTYPE html>
<html>
<head>
	<title>COURSE</title>
</head>
<body>
	<h1>PHP</h1>
	<p>Check out this video:</p>
	<?php
		$video_id = "VIDEO_ID_HERE";
		$video_name = "VIDEO_NAME_HERE";
		$link = "https://youtu.be/NqWP-pl1CfQ?list=PLu0W_9lII9aikXkRE0WxDt1vozo3hnmtR$video_id";
		echo "<a href='$link'>$video_name</a>";
	?>
</body>
</html>
