<?php
include 'connection.php';
// $id=$_POST['id'];

$log_id=$_POST['id'];
$about=$_POST['about'];

// $sql1 = mysqli_query($con, "INSERT INTO login(std_id,email,password,type)VALUES('$std_id','$email','$password','$type')");
// $login_id = mysqli_insert_id($con);
$sql=mysqli_query($con,"INSERT INTO about(log_id,about)VALUES('$log_id','$about')");

if ( $sql )
{
    $myarray['message'] = 'Added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>

