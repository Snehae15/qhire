<?php
include 'connection.php';
$id=$_POST['id'];
$sql = mysqli_query($con,"SELECT * FROM reg_student where std_id='$id'");
$list=array();

if($sql->num_rows>0){
    while($row = mysqli_fetch_assoc($sql)){
        $myarray['message']='viewed';
        $myarray['name']= $row['name'];
        $myarray['dob']= $row['dob'];
        $myarray['phone_no']= $row['phone_no'];
        $myarray['gender']= $row['gender'];
        $myarray['address']= $row['address'];
        $myarray['qualification']= $row['qualification'];
        $myarray['email']= $row['email'];
        $myarray['status']= $row['status'];
        $myarray['resume']= $row['resume'];

        array_push($list,$myarray);
    }
}
else{
    $myarray['message']='failed';
    array_push($list,$myarray);

}
echo json_encode($list);
?>