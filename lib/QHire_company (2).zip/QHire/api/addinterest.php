<?php
include 'connection.php';
// $id=$_POST['id'];

$log_id=$_POST['id'];
$interest=$_POST['interest'];

$sql=mysqli_query($con,"INSERT INTO interest(log_id,interest)VALUES('$log_id','$interest')");

if ( $sql )
{
    $myarray['message'] = 'Added';

} else {
    $myarray['message'] = 'failed';
}
echo json_encode($myarray);
?>

